package com.ssg.springwebsocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebSocketApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringWebSocketApplication.class, args);
    }

}
